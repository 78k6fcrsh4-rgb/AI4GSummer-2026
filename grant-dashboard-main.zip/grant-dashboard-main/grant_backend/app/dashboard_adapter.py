"""
Dashboard adapter
===================
Bridges the backend's GrantSnapshot to the EXACT JSON shape the existing
Grant_Reporting_Dashboard_Updated.html JavaScript already expects
(financeTableData, programTableData, revenueByFunder, deadlines), so the
existing frontend's render functions, sort handlers, filters, and
Data Sources tab can be pointed at these API responses with no rewrite of
the dashboard's navigation or tab logic — only its upload handlers need to
call these endpoints instead of reading the file purely client-side.
"""

from __future__ import annotations
from .schema import GrantSnapshot


def to_dashboard_json(snapshot: GrantSnapshot) -> dict:
    return {
        "organization": snapshot.organization,
        "periodLabel": snapshot.period_label,
        "financeTableData": [
            {"metric": f.metric, "month": f.month_value, "ytd": f.ytd_value, "budget": f.budget_ytd}
            for f in snapshot.finance
        ],
        "programTableData": [
            {"metric": p.metric, "month": p.month_value, "ytd": p.ytd_value, "goal": p.annual_goal}
            for p in snapshot.program_outcomes
        ],
        "revenueByFunder": [
            {"label": r.label, "amount": r.amount} for r in snapshot.revenue_by_source
        ],
        "deadlines": [
            {
                "id": d.id,
                "funder": d.funder,
                "report": d.report,
                "due": d.due.isoformat(),
                "owner": d.owner,
                "progress": d.progress.value,
                "criteria": [c.text for c in d.criteria],
            }
            for d in snapshot.deadlines
        ],
    }
