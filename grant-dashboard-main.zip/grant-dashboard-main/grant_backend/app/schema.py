"""
Common Grant Reporting Schema
==============================
This is the single internal data model every connector (DonorPerfect, Charity
Tracker, Excel/GL, EHR, award letters) normalizes INTO, and every funder
export normalizes OUT OF. It's the reason a single data entry can serve
multiple funders' different formats: enter/import once here, map many ways
downstream in app/mapping/funder_config.py.

No network calls, no LLM calls happen in this file. Pure data definitions.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import date
from enum import Enum
from typing import Optional


class ProgressState(str, Enum):
    NOT_STARTED = "not-started"
    IN_PROGRESS = "in-progress"
    SUBMITTED = "submitted"


class SourceSystem(str, Enum):
    DONOR_PERFECT = "donor_perfect"
    CHARITY_TRACKER = "charity_tracker"
    EXCEL_GL = "excel_gl"
    EHR = "ehr"
    AWARD_LETTER = "award_letter"
    MANUAL = "manual"


@dataclass
class FinanceMetric:
    """One row of the Finance tab. metric names are the join key across
    funders (e.g. 'Grant Revenue', 'Total Expenses')."""
    metric: str
    month_value: float
    ytd_value: float
    budget_ytd: float
    source: SourceSystem = SourceSystem.MANUAL

    @property
    def variance(self) -> float:
        return round(self.ytd_value - self.budget_ytd, 2)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["source"] = self.source.value
        d["variance"] = self.variance
        return d


@dataclass
class ProgramOutcome:
    """One row of the Program Outcomes tab."""
    metric: str
    month_value: float
    ytd_value: float
    annual_goal: float
    source: SourceSystem = SourceSystem.MANUAL

    @property
    def pct_to_goal(self) -> Optional[float]:
        if not self.annual_goal:
            return None
        return round(self.ytd_value / self.annual_goal, 4)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["source"] = self.source.value
        d["pct_to_goal"] = self.pct_to_goal
        return d


@dataclass
class RevenueSource:
    """One slice of the 'Revenue by Funding Source' donut."""
    label: str
    amount: float
    source: SourceSystem = SourceSystem.DONOR_PERFECT

    def to_dict(self) -> dict:
        d = asdict(self)
        d["source"] = self.source.value
        return d


@dataclass
class GrantCriterion:
    """A single funder requirement, stored funder-agnostically.
    `common_field` is the bridge into the shared schema: it tells the
    mapping engine which metric/outcome/field satisfies this requirement,
    so the SAME underlying number can be quoted correctly for every funder
    that asks for it under a different name/format."""
    text: str
    common_field: Optional[str] = None   # e.g. "program_outcomes.Participants Served"
    frequency: str = "per-report"        # monthly, quarterly, annual, per-report
    format_hint: Optional[str] = None    # e.g. "currency", "integer", "percent", "narrative"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Deadline:
    id: str
    funder: str
    report: str
    due: date
    owner: str = "Unassigned"
    progress: ProgressState = ProgressState.NOT_STARTED
    criteria: list[GrantCriterion] = field(default_factory=list)
    funder_profile_id: Optional[str] = None  # links to app/mapping funder profile

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "funder": self.funder,
            "report": self.report,
            "due": self.due.isoformat(),
            "owner": self.owner,
            "progress": self.progress.value,
            "criteria": [c.to_dict() for c in self.criteria],
            "funder_profile_id": self.funder_profile_id,
        }


@dataclass
class GrantSnapshot:
    """The full normalized bundle for a single reporting month. This is
    exactly what the dashboard's overview/finance/program tabs consume, and
    exactly what feeds the narrative generator and funder exports."""
    organization: str
    period_label: str  # e.g. "Jul 2026"
    finance: list[FinanceMetric] = field(default_factory=list)
    program_outcomes: list[ProgramOutcome] = field(default_factory=list)
    revenue_by_source: list[RevenueSource] = field(default_factory=list)
    deadlines: list[Deadline] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "organization": self.organization,
            "period_label": self.period_label,
            "finance": [f.to_dict() for f in self.finance],
            "program_outcomes": [p.to_dict() for p in self.program_outcomes],
            "revenue_by_source": [r.to_dict() for r in self.revenue_by_source],
            "deadlines": [d.to_dict() for d in self.deadlines],
        }

    def find_metric(self, name: str) -> Optional[FinanceMetric]:
        return next((f for f in self.finance if f.metric.lower() == name.lower()), None)

    def find_outcome(self, name: str) -> Optional[ProgramOutcome]:
        return next((p for p in self.program_outcomes if p.metric.lower() == name.lower()), None)

    def resolve_common_field(self, common_field: str):
        """common_field looks like 'finance.Grant Revenue' or
        'program_outcomes.Participants Served'. Returns the matching
        dataclass instance or None."""
        if not common_field or "." not in common_field:
            return None
        bucket, name = common_field.split(".", 1)
        if bucket == "finance":
            return self.find_metric(name)
        if bucket == "program_outcomes":
            return self.find_outcome(name)
        return None
