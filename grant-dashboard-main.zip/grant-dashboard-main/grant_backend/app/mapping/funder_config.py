"""
Funder mapping engine
=======================
This is the "single data entry maps to multiple funders' formats" piece.

A staffer enters or imports each metric ONCE, under one canonical name
(e.g. "Participants Served", "Grant Revenue") in the common schema
(app/schema.py). This module holds each funder's own vocabulary and
formatting rules (app/mapping/funder_profiles.json) and translates the
canonical snapshot into whatever labels/units that funder expects —
without ever re-entering the underlying number.

Add a new funder by adding one JSON block to funder_profiles.json. No code
change needed for a funder that only differs in field names/formatting.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Any

from ..schema import GrantSnapshot

PROFILES_PATH = Path(__file__).parent / "funder_profiles.json"


def _load_profiles() -> dict[str, dict]:
    with open(PROFILES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


_PROFILES_CACHE: dict[str, dict] | None = None


def get_profile(funder_profile_id: str) -> dict:
    global _PROFILES_CACHE
    if _PROFILES_CACHE is None:
        _PROFILES_CACHE = _load_profiles()
    return _PROFILES_CACHE.get(funder_profile_id, _PROFILES_CACHE["default"])


def list_profiles() -> dict[str, str]:
    global _PROFILES_CACHE
    if _PROFILES_CACHE is None:
        _PROFILES_CACHE = _load_profiles()
    return {key: p["label"] for key, p in _PROFILES_CACHE.items()}


def _format_currency(value: float, fmt: str) -> str:
    if fmt == "USD_CENTS":
        return f"${value:,.2f}"
    if fmt == "USD_DOLLARS_ROUNDED":
        return f"${round(value):,}"
    return f"${value:,.0f}"  # USD_DOLLARS default


def _format_count(value: float, fmt: str) -> str:
    if fmt == "INTEGER":
        return f"{round(value):,}"
    return f"{value:,.1f}"


def map_snapshot_for_funder(snapshot: GrantSnapshot, funder_profile_id: str) -> dict[str, Any]:
    """Returns finance/program rows relabeled and reformatted per the
    funder's profile, leaving the canonical snapshot untouched."""
    profile = get_profile(funder_profile_id)
    aliases = profile.get("field_aliases", {})

    finance_out = []
    for row in snapshot.finance:
        label = aliases.get(row.metric, row.metric)
        finance_out.append({
            "label": label,
            "month_value": _format_currency(row.month_value, profile["currency_format"]),
            "ytd_value": _format_currency(row.ytd_value, profile["currency_format"]),
            "budget_ytd": _format_currency(row.budget_ytd, profile["currency_format"]),
            "variance": _format_currency(row.variance, profile["currency_format"]),
        })

    program_out = []
    for row in snapshot.program_outcomes:
        label = aliases.get(row.metric, row.metric)
        pct = row.pct_to_goal
        program_out.append({
            "label": label,
            "month_value": _format_count(row.month_value, profile["count_format"]),
            "ytd_value": _format_count(row.ytd_value, profile["count_format"]),
            "annual_goal": _format_count(row.annual_goal, profile["count_format"]),
            "pct_to_goal": f"{pct*100:.0f}%" if pct is not None else "—",
        })

    return {
        "funder_profile": profile["label"],
        "reporting_frequency": profile["reporting_frequency"],
        "finance": finance_out,
        "program_outcomes": program_out,
    }
