"""
Lightweight storage layer.

A small nonprofit running this on a single staff laptop or a tiny VM doesn't
need a database server. This keeps one GrantSnapshot per reporting period
in memory, and persists to a local JSON file on every write so nothing is
lost between restarts. Swap this module out for SQLite/Postgres later
without touching any connector, mapping, or narrative code — everything
above this layer only talks to GrantSnapshot objects.
"""

from __future__ import annotations
import json
import threading
from datetime import date
from pathlib import Path

from .schema import (
    GrantSnapshot, FinanceMetric, ProgramOutcome, RevenueSource,
    Deadline, GrantCriterion, ProgressState, SourceSystem,
)

DATA_FILE = Path(__file__).parent.parent / "data" / "snapshots.json"
DATA_FILE.parent.mkdir(exist_ok=True)

_lock = threading.Lock()
_store: dict[str, GrantSnapshot] = {}


def _snapshot_to_json(snap: GrantSnapshot) -> dict:
    return snap.to_dict()


def _snapshot_from_json(period: str, data: dict) -> GrantSnapshot:
    return GrantSnapshot(
        organization=data["organization"],
        period_label=data["period_label"],
        finance=[FinanceMetric(f["metric"], f["month_value"], f["ytd_value"], f["budget_ytd"],
                                SourceSystem(f["source"])) for f in data.get("finance", [])],
        program_outcomes=[ProgramOutcome(p["metric"], p["month_value"], p["ytd_value"], p["annual_goal"],
                                          SourceSystem(p["source"])) for p in data.get("program_outcomes", [])],
        revenue_by_source=[RevenueSource(r["label"], r["amount"], SourceSystem(r["source"]))
                            for r in data.get("revenue_by_source", [])],
        deadlines=[Deadline(
            id=d["id"], funder=d["funder"], report=d["report"],
            due=date.fromisoformat(d["due"]), owner=d["owner"],
            progress=ProgressState(d["progress"]),
            criteria=[GrantCriterion(**c) for c in d.get("criteria", [])],
            funder_profile_id=d.get("funder_profile_id"),
        ) for d in data.get("deadlines", [])],
    )


def _load_all() -> None:
    if DATA_FILE.exists():
        raw = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        for period, data in raw.items():
            _store[period] = _snapshot_from_json(period, data)


def _persist() -> None:
    DATA_FILE.write_text(
        json.dumps({p: _snapshot_to_json(s) for p, s in _store.items()}, indent=2),
        encoding="utf-8",
    )


_load_all()


def get_or_create_snapshot(period_label: str, organization: str) -> GrantSnapshot:
    with _lock:
        if period_label not in _store:
            _store[period_label] = GrantSnapshot(organization=organization, period_label=period_label)
        return _store[period_label]


def save_snapshot(snapshot: GrantSnapshot) -> None:
    with _lock:
        _store[snapshot.period_label] = snapshot
        _persist()


def list_periods() -> list[str]:
    with _lock:
        return sorted(_store.keys())


def merge_finance_rows(snapshot: GrantSnapshot, rows: list[FinanceMetric]) -> None:
    """Upserts by metric name so re-uploading the same month's export
    updates rather than duplicates rows."""
    existing = {m.metric: m for m in snapshot.finance}
    for row in rows:
        existing[row.metric] = row
    snapshot.finance = list(existing.values())


def merge_program_rows(snapshot: GrantSnapshot, rows: list[ProgramOutcome]) -> None:
    existing = {p.metric: p for p in snapshot.program_outcomes}
    for row in rows:
        existing[row.metric] = row
    snapshot.program_outcomes = list(existing.values())


def merge_revenue_rows(snapshot: GrantSnapshot, rows: list[RevenueSource]) -> None:
    existing = {r.label: r for r in snapshot.revenue_by_source}
    for row in rows:
        existing[row.label] = row
    snapshot.revenue_by_source = list(existing.values())
