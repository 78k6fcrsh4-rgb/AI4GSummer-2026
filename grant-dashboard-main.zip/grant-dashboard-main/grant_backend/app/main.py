"""
Grant & Reporting Dashboard — Backend API
============================================

IMPORTANT / SECURITY NOTE ON LLM USE
-------------------------------------
No endpoint in this file — file upload, parsing, or export — ever sends
donor, client, or financial data to a language model. Uploads are parsed
with csv/openpyxl/regex (see app/connectors/*). Exports are built with
plain string templating and python-docx (see app/export/*, app/narrative/
generator.py). This is intentional: donor PII, client outcome data, and
funder-specific financial terms should never leave this process as an LLM
prompt. Keep it that way when extending this file.

Run locally:
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8000

Then point the existing dashboard's upload boxes / export buttons at these
endpoints (see README.md "Wiring into the existing dashboard").
"""

from __future__ import annotations
from datetime import date, datetime
from io import BytesIO

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response

from .schema import (
    Deadline, GrantCriterion, ProgressState, FinanceMetric, ProgramOutcome,
    RevenueSource, SourceSystem,
)
from .storage import (
    get_or_create_snapshot, save_snapshot, list_periods,
    merge_finance_rows, merge_program_rows, merge_revenue_rows,
)
from .dashboard_adapter import to_dashboard_json
from .connectors.donorperfect import DonorPerfectConnector
from .connectors.charity_tracker import CharityTrackerConnector
from .connectors.excel_gl import ExcelGLConnector
from .connectors.ehr import EHRConnector
from .connectors.award_letter import parse_award_letter_text
from .connectors.base import ParseError
from .mapping.funder_config import list_profiles
from .export.ics_export import build_ics
from .export.report_builder import build_report_text, build_report_docx
from .narrative.generator import (
    generate_funder_narrative, generate_board_deck_summary, generate_annual_report_paragraph,
)

app = FastAPI(title="Grant & Reporting Dashboard API", version="1.0.0")

# Local-first tool: allow the dashboard (served from file:// or localhost)
# to call this API. Tighten allow_origins before deploying beyond a single
# staff laptop / internal network.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

DEFAULT_ORG = "xChange Chicago"


def _snapshot(period: str, organization: str = DEFAULT_ORG):
    return get_or_create_snapshot(period, organization)


def _month_start(period: str) -> date:
    """period like 'Jul 2026' -> first day of that month, used to split
    month-value vs YTD when connectors aggregate raw exports."""
    return datetime.strptime(period, "%b %Y").date().replace(day=1)


def _fiscal_year_start(period: str) -> date:
    """Assumes calendar-year YTD; change here if the org's fiscal year
    doesn't start in January."""
    return _month_start(period).replace(month=1, day=1)


# ---------------------------------------------------------------- snapshot
@app.get("/api/periods")
def get_periods():
    return {"periods": list_periods()}


@app.get("/api/snapshot/{period}")
def get_snapshot(period: str, organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    return to_dashboard_json(snap)


# ----------------------------------------------------------------- uploads
@app.post("/api/upload/donorperfect")
async def upload_donorperfect(period: str = Form(...), organization: str = Form(DEFAULT_ORG),
                               file: UploadFile = File(...)):
    raw = await file.read()
    try:
        result = DonorPerfectConnector().parse(
            raw, month_start=_month_start(period), ytd_start=_fiscal_year_start(period),
        )
    except ParseError as e:
        raise HTTPException(status_code=400, detail=str(e))
    snap = _snapshot(period, organization)
    merge_finance_rows(snap, result["finance"])
    merge_revenue_rows(snap, result["revenue_by_source"])
    save_snapshot(snap)
    return {"rows_processed": result["rows_processed"], "snapshot": to_dashboard_json(snap)}


@app.post("/api/upload/charity-tracker")
async def upload_charity_tracker(period: str = Form(...), organization: str = Form(DEFAULT_ORG),
                                  file: UploadFile = File(...)):
    raw = await file.read()
    try:
        result = CharityTrackerConnector().parse(
            raw, month_start=_month_start(period), ytd_start=_fiscal_year_start(period),
        )
    except ParseError as e:
        raise HTTPException(status_code=400, detail=str(e))
    snap = _snapshot(period, organization)
    merge_program_rows(snap, result["program_outcomes"])
    save_snapshot(snap)
    return {"rows_processed": result["rows_processed"], "snapshot": to_dashboard_json(snap)}


@app.post("/api/upload/excel-gl")
async def upload_excel_gl(period: str = Form(...), organization: str = Form(DEFAULT_ORG),
                           file: UploadFile = File(...)):
    raw = await file.read()
    try:
        result = ExcelGLConnector().parse(raw, filename=file.filename or "")
    except ParseError as e:
        raise HTTPException(status_code=400, detail=str(e))
    snap = _snapshot(period, organization)
    merge_finance_rows(snap, result["finance"])
    save_snapshot(snap)
    return {"rows_processed": result["rows_processed"], "snapshot": to_dashboard_json(snap)}


@app.post("/api/upload/ehr")
async def upload_ehr(period: str = Form(...), organization: str = Form(DEFAULT_ORG),
                      file: UploadFile = File(...)):
    raw = await file.read()
    try:
        result = EHRConnector().parse(
            raw, month_start=_month_start(period), ytd_start=_fiscal_year_start(period),
        )
    except ParseError as e:
        raise HTTPException(status_code=400, detail=str(e))
    snap = _snapshot(period, organization)
    merge_program_rows(snap, result["program_outcomes"])
    save_snapshot(snap)
    return {"rows_processed": result["rows_processed"], "snapshot": to_dashboard_json(snap)}


@app.post("/api/finance/manual")
def add_finance_manual(period: str = Form(...), organization: str = Form(DEFAULT_ORG),
                        metric: str = Form(...), month: float = Form(...),
                        ytd: float = Form(...), budget: float = Form(...)):
    """Single-row manual entry from the Finance tab's '+ Add metric' form.
    Upserts by metric name, same as a connector upload."""
    snap = _snapshot(period, organization)
    merge_finance_rows(snap, [FinanceMetric(metric, month, ytd, budget, SourceSystem.MANUAL)])
    save_snapshot(snap)
    return to_dashboard_json(snap)


@app.post("/api/program/manual")
def add_program_manual(period: str = Form(...), organization: str = Form(DEFAULT_ORG),
                        metric: str = Form(...), month: float = Form(...),
                        ytd: float = Form(...), goal: float = Form(...)):
    """Single-row manual entry from the Program Outcomes tab's '+ Add metric' form."""
    snap = _snapshot(period, organization)
    merge_program_rows(snap, [ProgramOutcome(metric, month, ytd, goal, SourceSystem.MANUAL)])
    save_snapshot(snap)
    return to_dashboard_json(snap)


@app.post("/api/revenue/manual")
def add_revenue_manual(period: str = Form(...), organization: str = Form(DEFAULT_ORG),
                        label: str = Form(...), amount: float = Form(...)):
    """Single-row manual entry from the Finance tab's 'Revenue by Funding Source' form."""
    snap = _snapshot(period, organization)
    merge_revenue_rows(snap, [RevenueSource(label, amount, SourceSystem.MANUAL)])
    save_snapshot(snap)
    return to_dashboard_json(snap)


@app.delete("/api/finance/{period}/{metric}")
def remove_finance_manual(period: str, metric: str, organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    snap.finance = [f for f in snap.finance if f.metric != metric]
    save_snapshot(snap)
    return to_dashboard_json(snap)


@app.delete("/api/program/{period}/{metric}")
def remove_program_manual(period: str, metric: str, organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    snap.program_outcomes = [p for p in snap.program_outcomes if p.metric != metric]
    save_snapshot(snap)
    return to_dashboard_json(snap)


@app.post("/api/upload/award-letter")
async def upload_award_letter(text: str = Form(...)):
    """Accepts plain text (extract text from PDF/DOCX upstream with a
    dedicated library — see connectors/award_letter.py docstring). Returns
    suggestions only; nothing is written to a snapshot automatically."""
    return parse_award_letter_text(text)


# --------------------------------------------------------------- deadlines
@app.post("/api/deadlines")
def add_deadline(period: str = Form(...), organization: str = Form(DEFAULT_ORG),
                  funder: str = Form(...), report: str = Form(...), due: str = Form(...),
                  owner: str = Form("Unassigned"), criteria: str = Form(""),
                  funder_profile_id: str = Form("default")):
    snap = _snapshot(period, organization)
    next_id = f"d{len(snap.deadlines) + 1}"
    crit_list = [GrantCriterion(text=c.strip()) for c in criteria.split(",") if c.strip()]
    snap.deadlines.append(Deadline(
        id=next_id, funder=funder, report=report, due=date.fromisoformat(due),
        owner=owner or "Unassigned", criteria=crit_list, funder_profile_id=funder_profile_id,
    ))
    save_snapshot(snap)
    return to_dashboard_json(snap)


@app.put("/api/deadlines/{period}/{deadline_id}/progress")
def update_progress(period: str, deadline_id: str, progress: str = Form(...),
                     organization: str = Form(DEFAULT_ORG)):
    snap = _snapshot(period, organization)
    item = next((d for d in snap.deadlines if d.id == deadline_id), None)
    if not item:
        raise HTTPException(status_code=404, detail="Deadline not found")
    item.progress = ProgressState(progress)
    save_snapshot(snap)
    return to_dashboard_json(snap)


@app.delete("/api/deadlines/{period}/{deadline_id}")
def remove_deadline(period: str, deadline_id: str, organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    snap.deadlines = [d for d in snap.deadlines if d.id != deadline_id]
    save_snapshot(snap)
    return to_dashboard_json(snap)


@app.get("/api/funder-profiles")
def funder_profiles():
    return list_profiles()


# ----------------------------------------------------------------- exports
@app.get("/api/export/ics/{period}")
def export_all_ics(period: str, organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    if not snap.deadlines:
        raise HTTPException(status_code=400, detail="No deadlines to export yet.")
    ics_bytes = build_ics(snap.deadlines, snap.organization)
    return Response(
        content=ics_bytes, media_type="text/calendar",
        headers={"Content-Disposition": f'attachment; filename="{snap.organization}_deadlines.ics"'},
    )


@app.get("/api/export/report/{period}/{deadline_id}")
def export_report(period: str, deadline_id: str, fmt: str = "txt",
                   organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    item = next((d for d in snap.deadlines if d.id == deadline_id), None)
    if not item:
        raise HTTPException(status_code=404, detail="Deadline not found")
    profile_id = item.funder_profile_id or "default"

    if fmt == "docx":
        try:
            content = build_report_docx(snap, item, profile_id)
        except ImportError:
            raise HTTPException(status_code=501, detail="python-docx not installed; run pip install python-docx")
        return Response(
            content=content,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f'attachment; filename="{item.funder}_report_template.docx"'},
        )

    content = build_report_text(snap, item, profile_id)
    return Response(
        content=content, media_type="text/plain",
        headers={"Content-Disposition": f'attachment; filename="{item.funder}_report_template.txt"'},
    )


@app.get("/api/export/narrative/{period}/{deadline_id}")
def export_narrative(period: str, deadline_id: str, organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    item = next((d for d in snap.deadlines if d.id == deadline_id), None)
    if not item:
        raise HTTPException(status_code=404, detail="Deadline not found")
    return {"narrative": generate_funder_narrative(snap, item.funder, item.report)}


@app.get("/api/export/board-deck/{period}")
def export_board_deck(period: str, organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    return {"slides": generate_board_deck_summary(snap)}


@app.get("/api/export/annual-report-paragraph/{period}")
def export_annual_report_paragraph(period: str, organization: str = DEFAULT_ORG):
    snap = _snapshot(period, organization)
    return {"paragraph": generate_annual_report_paragraph(snap)}


@app.get("/api/health")
def health():
    return {"status": "ok"}
