"""
Narrative summary generator
=============================
Turns raw metrics into narrative-ready outcome summaries for funders, board
decks, and reports — WITHOUT calling an LLM. This is a template/rule-based
generator: it selects and fills sentence templates based on the numbers
themselves (variance sign, % to goal, trend direction), so output is
fully deterministic and reproducible from the same input every time.
That determinism is a deliberate design choice for this pipeline: finance
and client-outcome figures should never depend on a model's sampling.

Output is plain text, ready to paste into a funder narrative field, a board
deck speaker note, or a report cover memo.
"""

from __future__ import annotations
from ..schema import GrantSnapshot, FinanceMetric, ProgramOutcome


def _finance_sentence(m: FinanceMetric) -> str:
    variance = m.variance
    if variance > 0:
        tone = f"tracking ${variance:,.0f} ahead of the year-to-date budget"
    elif variance < 0:
        tone = f"tracking ${abs(variance):,.0f} behind the year-to-date budget"
    else:
        tone = "exactly on budget year-to-date"
    return (
        f"{m.metric} totaled ${m.month_value:,.0f} this month and "
        f"${m.ytd_value:,.0f} year-to-date, {tone} (${m.budget_ytd:,.0f})."
    )


def _outcome_sentence(p: ProgramOutcome) -> str:
    pct = p.pct_to_goal
    if pct is None:
        goal_clause = "no annual goal has been set for this metric yet"
    elif pct >= 1.0:
        goal_clause = f"already exceeding its annual goal of {p.annual_goal:,.0f} ({pct*100:.0f}%)"
    elif pct >= 0.75:
        goal_clause = f"on pace to reach its annual goal of {p.annual_goal:,.0f} ({pct*100:.0f}% achieved)"
    else:
        goal_clause = f"at {pct*100:.0f}% of its annual goal of {p.annual_goal:,.0f}"
    return (
        f"{p.metric} reached {p.month_value:,.0f} this month and "
        f"{p.ytd_value:,.0f} year-to-date, {goal_clause}."
    )


def generate_funder_narrative(snapshot: GrantSnapshot, funder: str, report: str) -> str:
    """A short narrative paragraph suitable for a funder report's
    'progress summary' field."""
    lines = [
        f"During {snapshot.period_label}, {snapshot.organization} continued delivering on the "
        f"commitments outlined in its agreement with {funder} ({report})."
    ]
    if snapshot.program_outcomes:
        lines.append(" ".join(_outcome_sentence(p) for p in snapshot.program_outcomes))
    if snapshot.finance:
        lines.append(" ".join(_finance_sentence(m) for m in snapshot.finance))
    if snapshot.revenue_by_source:
        top = max(snapshot.revenue_by_source, key=lambda r: r.amount)
        lines.append(
            f"The largest funding source for the period was {top.label} "
            f"(${top.amount:,.0f}), reflecting a diversified revenue base across "
            f"{len(snapshot.revenue_by_source)} funding sources."
        )
    return "\n\n".join(lines)


def generate_board_deck_summary(snapshot: GrantSnapshot) -> list[dict[str, str]]:
    """Returns one slide-note per section, meant to drop directly into a
    board deck's speaker notes or an appendix slide."""
    slides = []

    if snapshot.finance:
        slides.append({
            "title": f"Finance Summary — {snapshot.period_label}",
            "body": " ".join(_finance_sentence(m) for m in snapshot.finance),
        })

    if snapshot.program_outcomes:
        slides.append({
            "title": f"Program Outcomes — {snapshot.period_label}",
            "body": " ".join(_outcome_sentence(p) for p in snapshot.program_outcomes),
        })

    upcoming = [d for d in snapshot.deadlines]
    if upcoming:
        due_list = ", ".join(f"{d.funder} ({d.report}) due {d.due.isoformat()}" for d in upcoming)
        slides.append({
            "title": "Upcoming Funder Reporting",
            "body": f"Reports in progress or upcoming: {due_list}.",
        })

    return slides


def generate_annual_report_paragraph(snapshot: GrantSnapshot) -> str:
    """A slightly more celebratory tone for public-facing annual report
    copy, still fully derived from the numbers — no invented claims."""
    outcome_clause = ""
    if snapshot.program_outcomes:
        top_outcome = max(snapshot.program_outcomes, key=lambda p: p.ytd_value)
        outcome_clause = (
            f" Most notably, {snapshot.organization} recorded {top_outcome.ytd_value:,.0f} "
            f"in {top_outcome.metric.lower()} year-to-date."
        )
    revenue_clause = ""
    if snapshot.finance:
        revenue_row = next((m for m in snapshot.finance if "revenue" in m.metric.lower()), None)
        if revenue_row:
            revenue_clause = (
                f" This work was made possible by ${revenue_row.ytd_value:,.0f} in "
                f"{revenue_row.metric.lower()} raised so far this fiscal year."
            )
    return (
        f"In {snapshot.period_label}, {snapshot.organization} continued its work in the community."
        f"{outcome_clause}{revenue_clause}"
    ).strip()
