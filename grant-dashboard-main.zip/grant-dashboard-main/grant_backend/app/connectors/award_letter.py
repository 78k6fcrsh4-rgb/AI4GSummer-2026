"""
Award letter / grant agreement connector
==========================================
Extracts a candidate due date and a candidate list of reporting
requirements ("criteria") from an uploaded award letter or grant agreement
so a staffer doesn't have to retype them into the Deadline Tracker.

This is deliberately rule-based (regex + keyword heuristics), NOT an LLM
call — award letters can contain sensitive funder terms and financial
figures, and this pipeline's requirement is that upload/parse/export logic
never routes document contents through a model. Because of that, extraction
here is best-effort: results are always returned as *suggestions* for a
human to confirm/edit on the Deadline Tracker tab, never auto-committed.

Supports .txt directly. For .pdf/.docx, pass already-extracted text (use a
text-extraction library upstream, e.g. pdfminer.six / python-docx) — this
module intentionally does not parse binary formats itself, keeping the
"no document contents reach a model" boundary easy to audit in one place.
"""

from __future__ import annotations
import re
from datetime import datetime
from typing import Any

DATE_PATTERNS = [
    r"\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}\b",
    r"\b\d{1,2}/\d{1,2}/\d{4}\b",
    r"\b\d{4}-\d{2}-\d{2}\b",
]

DUE_CONTEXT_WORDS = ("due", "deadline", "submit", "submission", "no later than", "by")

CRITERIA_KEYWORDS = (
    "must report", "must include", "shall report", "shall include", "is required to",
    "required to submit", "report must", "please include", "reporting requirements",
    "grantee must", "grantee shall",
)


def extract_candidate_dates(text: str) -> list[dict[str, str]]:
    """Returns dates found near due/deadline language, each with the
    surrounding sentence as context for human review."""
    results = []
    sentences = re.split(r"(?<=[.!?])\s+", text)
    for sentence in sentences:
        lowered = sentence.lower()
        if not any(w in lowered for w in DUE_CONTEXT_WORDS):
            continue
        for pattern in DATE_PATTERNS:
            for match in re.finditer(pattern, sentence):
                parsed = _try_parse(match.group(0))
                if parsed:
                    results.append({
                        "raw_text": match.group(0),
                        "parsed_date": parsed.isoformat(),
                        "context": sentence.strip(),
                    })
    return results


def extract_candidate_criteria(text: str) -> list[str]:
    """Pulls sentences that read like reporting obligations. Deduplicated,
    trimmed, capped at a reasonable count — meant to seed the criteria
    list, not replace a human read of the agreement."""
    sentences = re.split(r"(?<=[.!?])\s+", text)
    found = []
    for sentence in sentences:
        lowered = sentence.lower()
        if any(k in lowered for k in CRITERIA_KEYWORDS):
            cleaned = re.sub(r"\s+", " ", sentence).strip()
            if cleaned and cleaned not in found:
                found.append(cleaned)
    return found[:25]


def _try_parse(raw: str) -> "datetime.date | None":
    for fmt in ("%B %d, %Y", "%B %d %Y", "%m/%d/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw.replace(",", ""), fmt.replace(",", "")).date()
        except ValueError:
            continue
    return None


def parse_award_letter_text(text: str) -> dict[str, Any]:
    return {
        "candidate_due_dates": extract_candidate_dates(text),
        "candidate_criteria": extract_candidate_criteria(text),
        "note": "Suggestions only — confirm and edit on the Deadline Tracker tab before relying on them.",
    }
