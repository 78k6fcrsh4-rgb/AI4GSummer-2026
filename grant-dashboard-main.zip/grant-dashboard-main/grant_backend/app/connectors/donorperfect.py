"""
DonorPerfect connector
=======================
Automates the "manually pull and reformat" step for DonorPerfect. Two modes:

1. CSV export mode (default) — staff exports Gifts/Revenue report from
   DonorPerfect monthly and uploads it via /api/upload/donorperfect.
   Expected columns (DonorPerfect's standard gift export headers, case
   insensitive): gift_date, amount, gl_code (or fund/campaign), donor_id.

2. Live API mode (optional) — if DONORPERFECT_API_KEY is set in the
   environment, `pull_from_api()` calls DonorPerfect's REST API directly so
   the monthly export step can be skipped entirely. This still never sends
   donor data to an LLM — it's a plain authenticated HTTPS GET, parsed with
   the same normalization logic as the CSV path.
"""

from __future__ import annotations
import os
from datetime import date
from collections import defaultdict
from typing import Any

import requests  # only used for the optional live-API mode

from .base import BaseConnector, ParseError
from ..schema import FinanceMetric, RevenueSource, SourceSystem

DONORPERFECT_API_BASE = "https://data.donorperfect.net/api/v3"


class DonorPerfectConnector(BaseConnector):
    required_columns = ("gift_date", "amount")

    # GL codes / fund codes -> which finance metric bucket they roll into.
    # Nonprofits can extend this without touching parsing logic.
    GL_CODE_MAP = {
        "grant": "Grant Revenue",
        "grants": "Grant Revenue",
        "foundation": "Grant Revenue",
        "individual": "Individual Giving",
        "annual fund": "Individual Giving",
        "event": "Event Revenue",
        "special event": "Event Revenue",
        "in-kind": "In-Kind Revenue",
    }

    def _bucket_for(self, gl_code: str) -> str:
        gl_code = (gl_code or "").lower()
        for key, bucket in self.GL_CODE_MAP.items():
            if key in gl_code:
                return bucket
        return "Other Contributed Revenue"

    def parse(self, raw_bytes: bytes, month_start: date | None = None,
              ytd_start: date | None = None, budget_lookup: dict[str, float] | None = None
              ) -> dict[str, Any]:
        rows = self.load_csv_rows(raw_bytes)
        budget_lookup = budget_lookup or {}

        month_totals: dict[str, float] = defaultdict(float)
        ytd_totals: dict[str, float] = defaultdict(float)
        by_source: dict[str, float] = defaultdict(float)

        for row in rows:
            try:
                gift_date = self._parse_date(row["gift_date"])
            except ValueError as e:
                raise ParseError(f"Unrecognized date '{row['gift_date']}' in gift_date column.") from e
            amount = self.to_float(row.get("amount", "0"))
            gl_code = row.get("gl_code") or row.get("fund") or row.get("campaign") or ""
            bucket = self._bucket_for(gl_code)
            source_label = (row.get("fund") or row.get("campaign") or gl_code or "Unrestricted").title()

            if ytd_start is None or gift_date >= ytd_start:
                ytd_totals[bucket] += amount
                by_source[source_label] += amount
            if month_start is None or (gift_date.year == month_start.year and gift_date.month == month_start.month):
                month_totals[bucket] += amount

        finance = [
            FinanceMetric(
                metric=bucket,
                month_value=round(month_totals.get(bucket, 0.0), 2),
                ytd_value=round(ytd_totals.get(bucket, 0.0), 2),
                budget_ytd=round(budget_lookup.get(bucket, 0.0), 2),
                source=SourceSystem.DONOR_PERFECT,
            )
            for bucket in sorted(set(month_totals) | set(ytd_totals))
        ]

        revenue_by_source = [
            RevenueSource(label=label, amount=round(amount, 2), source=SourceSystem.DONOR_PERFECT)
            for label, amount in sorted(by_source.items(), key=lambda kv: -kv[1])
        ]

        return {
            "finance": finance,
            "revenue_by_source": revenue_by_source,
            "rows_processed": len(rows),
        }

    @staticmethod
    def _parse_date(value: str) -> date:
        for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y"):
            try:
                from datetime import datetime
                return datetime.strptime(value, fmt).date()
            except ValueError:
                continue
        raise ValueError(value)

    # ---------------- Optional live API mode ----------------
    def pull_from_api(self, since: date, until: date) -> bytes:
        """Fetches gifts directly from DonorPerfect's REST API and returns
        them as CSV bytes, so they can flow through the same `parse()` used
        for uploaded files. Requires DONORPERFECT_API_KEY env var."""
        api_key = os.environ.get("DONORPERFECT_API_KEY")
        if not api_key:
            raise RuntimeError(
                "DONORPERFECT_API_KEY not set — falling back to manual CSV export/upload."
            )
        resp = requests.get(
            f"{DONORPERFECT_API_BASE}/gifts",
            headers={"x-apikey": api_key},
            params={"date_from": since.isoformat(), "date_to": until.isoformat()},
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        # Normalize API JSON rows into the same CSV shape parse() expects.
        import csv, io
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=["gift_date", "amount", "gl_code", "fund", "donor_id"])
        writer.writeheader()
        for rec in data.get("gifts", []):
            writer.writerow({
                "gift_date": rec.get("gift_date", ""),
                "amount": rec.get("amount", 0),
                "gl_code": rec.get("gl_code", ""),
                "fund": rec.get("fund_code", ""),
                "donor_id": rec.get("donor_id", ""),
            })
        return buf.getvalue().encode("utf-8")
