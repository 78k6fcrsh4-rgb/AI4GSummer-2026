"""
Charity Tracker connector
===========================
Closes the "Charity Tracker data efficiency gap": Charity Tracker exports
case/session/outcome activity as one row per client touchpoint, but funder
reports need aggregated monthly/YTD counts per outcome metric. This
connector does that aggregation once, here, instead of every staffer
re-tallying rows in Excel by hand before each report.

Expected export columns (case-insensitive): case_id, service_date,
outcome_metric, outcome_value, program.
"""

from __future__ import annotations
from collections import defaultdict
from datetime import date, datetime
from typing import Any

from .base import BaseConnector, ParseError
from ..schema import ProgramOutcome, SourceSystem


class CharityTrackerConnector(BaseConnector):
    required_columns = ("service_date", "outcome_metric", "outcome_value")

    def parse(self, raw_bytes: bytes, month_start: date | None = None,
              ytd_start: date | None = None, goal_lookup: dict[str, float] | None = None
              ) -> dict[str, Any]:
        rows = self.load_csv_rows(raw_bytes)
        goal_lookup = goal_lookup or {}

        month_totals: dict[str, float] = defaultdict(float)
        ytd_totals: dict[str, float] = defaultdict(float)
        distinct_cases_month: dict[str, set] = defaultdict(set)
        distinct_cases_ytd: dict[str, set] = defaultdict(set)

        for row in rows:
            try:
                service_date = self._parse_date(row["service_date"])
            except ValueError as e:
                raise ParseError(f"Unrecognized date '{row['service_date']}' in service_date column.") from e
            metric = (row.get("outcome_metric") or "Unlabeled Outcome").strip()
            value = self.to_float(row.get("outcome_value", "1"), default=1.0)
            case_id = row.get("case_id", "")

            if ytd_start is None or service_date >= ytd_start:
                ytd_totals[metric] += value
                if case_id:
                    distinct_cases_ytd[metric].add(case_id)
            if month_start is None or (service_date.year == month_start.year and service_date.month == month_start.month):
                month_totals[metric] += value
                if case_id:
                    distinct_cases_month[metric].add(case_id)

        outcomes = [
            ProgramOutcome(
                metric=metric,
                month_value=round(month_totals.get(metric, 0.0), 2),
                ytd_value=round(ytd_totals.get(metric, 0.0), 2),
                annual_goal=goal_lookup.get(metric, 0.0),
                source=SourceSystem.CHARITY_TRACKER,
            )
            for metric in sorted(set(month_totals) | set(ytd_totals))
        ]

        return {
            "program_outcomes": outcomes,
            "unique_cases_month": {k: len(v) for k, v in distinct_cases_month.items()},
            "unique_cases_ytd": {k: len(v) for k, v in distinct_cases_ytd.items()},
            "rows_processed": len(rows),
        }

    @staticmethod
    def _parse_date(value: str) -> date:
        for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y"):
            try:
                return datetime.strptime(value, fmt).date()
            except ValueError:
                continue
        raise ValueError(value)
