"""
Excel / General Ledger connector
==================================
Most small nonprofits keep budget-vs-actual in an Excel workbook maintained
by a bookkeeper or fractional CFO. This connector reads that workbook (or a
CSV export of it) and produces the "Budget YTD" side of the Finance table —
the piece DonorPerfect alone can't provide, since DonorPerfect only tracks
revenue, not the expense/budget side.

Accepts either:
  - .csv with columns: gl_line, month_actual, ytd_actual, ytd_budget
  - .xlsx with a sheet containing the same four columns (any sheet name;
    the first sheet with a recognizable header row is used)
"""

from __future__ import annotations
import io
from typing import Any

from openpyxl import load_workbook

from .base import BaseConnector, ParseError
from ..schema import FinanceMetric, SourceSystem

EXPECTED_HEADERS = {"gl_line", "month_actual", "ytd_actual", "ytd_budget"}


class ExcelGLConnector(BaseConnector):
    required_columns = ("gl_line", "month_actual", "ytd_actual", "ytd_budget")

    def parse(self, raw_bytes: bytes, filename: str = "") -> dict[str, Any]:
        if filename.lower().endswith((".xlsx", ".xlsm")):
            rows = self._rows_from_xlsx(raw_bytes)
        else:
            rows = self.load_csv_rows(raw_bytes)

        finance = []
        for row in rows:
            metric = row.get("gl_line", "").strip()
            if not metric:
                continue
            finance.append(FinanceMetric(
                metric=metric,
                month_value=round(self.to_float(row.get("month_actual", "0")), 2),
                ytd_value=round(self.to_float(row.get("ytd_actual", "0")), 2),
                budget_ytd=round(self.to_float(row.get("ytd_budget", "0")), 2),
                source=SourceSystem.EXCEL_GL,
            ))

        return {"finance": finance, "rows_processed": len(rows)}

    def _rows_from_xlsx(self, raw_bytes: bytes) -> list[dict[str, str]]:
        wb = load_workbook(io.BytesIO(raw_bytes), data_only=True, read_only=True)
        for sheet in wb.worksheets:
            rows_iter = sheet.iter_rows(values_only=True)
            try:
                header = next(rows_iter)
            except StopIteration:
                continue
            normalized = [str(h).strip().lower() if h else "" for h in header]
            if not EXPECTED_HEADERS.issubset(set(normalized)):
                continue
            col_index = {name: idx for idx, name in enumerate(normalized)}
            out = []
            for raw_row in rows_iter:
                if raw_row is None or all(c is None for c in raw_row):
                    continue
                out.append({
                    key: ("" if idx >= len(raw_row) or raw_row[idx] is None else str(raw_row[idx]))
                    for key, idx in col_index.items()
                })
            return out
        raise ParseError(
            f"No sheet found with expected header columns: {', '.join(sorted(EXPECTED_HEADERS))}"
        )
