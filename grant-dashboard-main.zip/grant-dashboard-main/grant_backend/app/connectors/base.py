"""
Base connector contract.

Every connector takes raw bytes (a CSV/XLSX export a staffer uploaded, or an
API payload) and returns plain Python dict/list structures shaped like the
common schema in app/schema.py. Parsing here is 100% deterministic —
csv/openpyxl/regex only. No model or LLM call is ever made against uploaded
file contents; that's a hard requirement for this pipeline (donor and client
data must never leave the process as a prompt).
"""

from __future__ import annotations
import csv
import io
from abc import ABC, abstractmethod
from typing import Any


class ParseError(Exception):
    """Raised when an uploaded export doesn't match the expected column
    layout. Message is meant to be shown directly to the staff member."""


class BaseConnector(ABC):
    #: subclasses declare the column names they require to exist in the CSV
    required_columns: tuple[str, ...] = ()

    def load_csv_rows(self, raw_bytes: bytes) -> list[dict[str, str]]:
        text = raw_bytes.decode("utf-8-sig", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        if reader.fieldnames is None:
            raise ParseError("File appears to be empty.")
        normalized_fields = {f.strip().lower(): f for f in reader.fieldnames}
        missing = [c for c in self.required_columns if c not in normalized_fields]
        if missing:
            raise ParseError(
                f"Missing expected column(s): {', '.join(missing)}. "
                f"Found columns: {', '.join(reader.fieldnames)}"
            )
        rows = []
        for row in reader:
            rows.append({k.strip().lower(): (v or "").strip() for k, v in row.items()})
        return rows

    @staticmethod
    def to_float(value: str, default: float = 0.0) -> float:
        if value is None:
            return default
        cleaned = value.replace("$", "").replace(",", "").strip()
        if cleaned in ("", "-", "—"):
            return default
        try:
            return float(cleaned)
        except ValueError:
            return default

    @abstractmethod
    def parse(self, raw_bytes: bytes) -> dict[str, Any]:
        """Return a dict of normalized schema fragments, e.g.
        {'finance': [...], 'revenue_by_source': [...]}"""
        raise NotImplementedError
