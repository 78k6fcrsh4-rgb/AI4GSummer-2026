"""
EHR connector
==============
For programs with a clinical/behavioral-health component, the EHR is often
the source of truth for service counts (screenings, referrals, encounters)
that funders want reported alongside Charity Tracker's case-management
metrics. This connector aggregates an EHR encounter export into the same
ProgramOutcome shape used elsewhere.

Privacy note: only aggregate counts are ever produced or retained by this
connector. Row-level fields other than encounter_type/encounter_date/
client_ref are read only to compute counts and are discarded immediately —
client_ref is used solely to deduplicate unique clients per metric and is
never written to output or logs.

Expected columns (case-insensitive): encounter_date, encounter_type,
client_ref (a de-identified ID, not a name).
"""

from __future__ import annotations
from collections import defaultdict
from datetime import date, datetime
from typing import Any

from .base import BaseConnector, ParseError
from ..schema import ProgramOutcome, SourceSystem

# Maps raw EHR encounter_type values to the outcome metric name used
# elsewhere on the dashboard. Extend per-organization as needed.
ENCOUNTER_TYPE_MAP = {
    "screening": "Screenings Completed",
    "referral": "Referrals Made",
    "intake": "Intakes Completed",
    "follow-up": "Follow-Up Visits",
    "followup": "Follow-Up Visits",
}


class EHRConnector(BaseConnector):
    required_columns = ("encounter_date", "encounter_type")

    def parse(self, raw_bytes: bytes, month_start: date | None = None,
              ytd_start: date | None = None, goal_lookup: dict[str, float] | None = None
              ) -> dict[str, Any]:
        rows = self.load_csv_rows(raw_bytes)
        goal_lookup = goal_lookup or {}

        month_counts: dict[str, int] = defaultdict(int)
        ytd_counts: dict[str, int] = defaultdict(int)
        seen_month: dict[str, set] = defaultdict(set)
        seen_ytd: dict[str, set] = defaultdict(set)

        for row in rows:
            try:
                enc_date = self._parse_date(row["encounter_date"])
            except ValueError as e:
                raise ParseError(f"Unrecognized date '{row['encounter_date']}' in encounter_date column.") from e
            raw_type = (row.get("encounter_type") or "").strip().lower()
            metric = ENCOUNTER_TYPE_MAP.get(raw_type, raw_type.title() or "Encounters")
            client_ref = row.get("client_ref", "")

            if ytd_start is None or enc_date >= ytd_start:
                if client_ref and client_ref in seen_ytd[metric]:
                    pass  # count once per client per metric, YTD
                else:
                    ytd_counts[metric] += 1
                    if client_ref:
                        seen_ytd[metric].add(client_ref)
            if month_start is None or (enc_date.year == month_start.year and enc_date.month == month_start.month):
                if client_ref and client_ref in seen_month[metric]:
                    pass
                else:
                    month_counts[metric] += 1
                    if client_ref:
                        seen_month[metric].add(client_ref)

        outcomes = [
            ProgramOutcome(
                metric=metric,
                month_value=float(month_counts.get(metric, 0)),
                ytd_value=float(ytd_counts.get(metric, 0)),
                annual_goal=goal_lookup.get(metric, 0.0),
                source=SourceSystem.EHR,
            )
            for metric in sorted(set(month_counts) | set(ytd_counts))
        ]

        return {"program_outcomes": outcomes, "rows_processed": len(rows)}

    @staticmethod
    def _parse_date(value: str) -> date:
        for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y"):
            try:
                return datetime.strptime(value, fmt).date()
            except ValueError:
                continue
        raise ValueError(value)
