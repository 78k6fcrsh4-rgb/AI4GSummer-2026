"""
.ics calendar export — server-side equivalent of the dashboard's
"Add to calendar" buttons, so deadlines can also be pushed from an
automated pipeline (e.g. a nightly job) rather than only on click.
"""

from __future__ import annotations
from datetime import datetime, timezone
from ..schema import Deadline


def _to_ics_date(dt: datetime) -> str:
    return dt.strftime("%Y%m%dT%H%M%SZ")


def _event_block(item: Deadline) -> str:
    start = datetime(item.due.year, item.due.month, item.due.day, 9, 0, tzinfo=timezone.utc)
    end = start.replace(hour=10)
    criteria_text = "; ".join(c.text.replace(",", ";") for c in item.criteria)
    return "\r\n".join([
        "BEGIN:VEVENT",
        f"UID:{item.id}-{int(start.timestamp())}@grant-dashboard",
        f"DTSTAMP:{_to_ics_date(datetime.now(timezone.utc))}",
        f"DTSTART:{_to_ics_date(start)}",
        f"DTEND:{_to_ics_date(end)}",
        f"SUMMARY:{item.funder} \u2014 {item.report} due",
        f"DESCRIPTION:Owner: {item.owner}. Required: {criteria_text}",
        "END:VEVENT",
    ])


def build_ics(deadlines: list[Deadline], org_name: str) -> bytes:
    body = "\r\n".join(_event_block(d) for d in deadlines)
    ics = "\r\n".join([
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        f"PRODID:-//{org_name}//Grant Dashboard//EN",
        body,
        "END:VCALENDAR",
    ])
    return ics.encode("utf-8")
