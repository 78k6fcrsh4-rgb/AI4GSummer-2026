# Grant & Reporting Dashboard — Backend

Lightweight integration backend behind `Grant_Reporting_Dashboard_Updated.html`.
Connects DonorPerfect, Charity Tracker, an EHR, and Excel/GL exports into one
normalized schema, maps that single schema into any funder's own field names,
and drafts narrative-ready summaries — all without ever routing uploaded
donor/client/financial data through an LLM.

## Why this exists

The dashboard's frontend already looks and behaves right, but its upload
boxes only read a file's *shape* client-side ("N rows detected") — nothing
was actually parsed, aggregated, or mapped anywhere. This backend is the
part that does the real work:

1. **Automates DonorPerfect** — parses gift/revenue exports (or pulls live
   from DonorPerfect's API if `DONORPERFECT_API_KEY` is set) and rolls gifts
   up into month/YTD revenue by GL code, closing the "manually pull and
   reformat" gap.
2. **Standardizes grant criteria into one schema** — every metric is entered
   or imported once, under one canonical name (`app/schema.py`). Funder-
   specific vocabulary/formatting lives entirely in
   `app/mapping/funder_profiles.json` — add a funder there, not in code.
3. **Closes the Charity Tracker gap** — aggregates row-per-touchpoint case
   exports into month/YTD counts per outcome metric automatically.
4. **Reads Excel/GL exports** for the budget-vs-actual side DonorPerfect
   doesn't cover.
5. **Reads EHR encounter exports** for programs with a clinical component,
   de-duplicating by client per metric without retaining any PHI beyond a
   de-identified reference used only for the count.
6. **Turns metrics into narrative** — `app/narrative/generator.py` is a
   deterministic, template-based writer (not an LLM) that drafts funder
   progress paragraphs, board-deck slide notes, and annual-report copy
   straight from the numbers.

## No LLM in the upload/export path — by design

Every connector (`app/connectors/*`) and every exporter (`app/export/*`,
`app/narrative/generator.py`) is plain Python: `csv`, `openpyxl`, `regex`,
string templates, `python-docx`. Donor gift amounts, client outcome data,
and funder-specific contract terms never get serialized into a prompt. This
is called out again in `app/main.py`'s module docstring so it stays true as
the code evolves.

## Project layout

```
app/
  schema.py              Common schema every connector normalizes into
  storage.py              JSON-file-backed snapshot store (swap for SQL later)
  dashboard_adapter.py    Snapshot -> exact JSON shape the existing HTML/JS expects
  connectors/
    donorperfect.py       CSV export parser + optional live API pull
    charity_tracker.py    Case/session export -> aggregated outcome metrics
    excel_gl.py            Budget/GL workbook (.xlsx or .csv) -> finance rows
    ehr.py                 Encounter export -> aggregated outcome metrics
    award_letter.py        Regex-based due-date/criteria suggestion extractor
  mapping/
    funder_profiles.json   Per-funder field-name aliases + formatting rules
    funder_config.py       Applies a funder profile to a snapshot
  narrative/
    generator.py            Template-based narrative writer (funder / board / annual report)
  export/
    ics_export.py           .ics calendar generation
    report_builder.py       .txt and .docx funder report templates
  main.py                  FastAPI app wiring it all together
data/
  snapshots.json           Created on first run; one snapshot per reporting month
```

## Running it

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Interactive API docs: `http://localhost:8000/docs`

Optional live DonorPerfect pull instead of manual CSV export:

```bash
export DONORPERFECT_API_KEY=your_key_here
```

## Wiring into the existing dashboard — done

The dashboard (`Grant_Reporting_Dashboard_Updated (2).html` at the repo
root) now calls these endpoints directly. Run the backend
(`uvicorn app.main:app --reload --port 8000`) and open the HTML file — a
banner under the header confirms whether it found the backend at
`http://localhost:8000`. If the backend isn't running, or is on a
different host/port, the dashboard falls back to local-only editing
(nothing persists) so it's still usable for a quick look; point it at a
different backend by setting `window.API_BASE = "http://host:port"` in a
`<script>` tag before the dashboard's own script runs.

What's wired:
- All four CSV/XLSX upload boxes (DonorPerfect, Charity Tracker, Excel/GL,
  and a new EHR box) POST to their `/api/upload/*` connector endpoints and
  render the returned snapshot. EHR requires the backend (de-duplication
  happens server-side, so there's no local-only fallback for it).
- The Finance/Program/Revenue "+ Add" forms POST to three small new
  endpoints — `/api/finance/manual`, `/api/program/manual`,
  `/api/revenue/manual` — added specifically to give manual entry
  somewhere to persist to (the connectors alone only covered file
  uploads). Matching `DELETE /api/finance/{period}/{metric}` and
  `/api/program/{period}/{metric}` back the "Remove" buttons.
- Adding/removing a deadline and changing its progress call
  `POST /api/deadlines`, `DELETE /api/deadlines/{period}/{id}`, and
  `PUT /api/deadlines/{period}/{id}/progress`. The bulk deadline CSV box
  still parses client-side (no bulk endpoint exists) but now posts each
  row through the same single-deadline endpoint instead of only holding
  it in memory.
- The award letter box's PDF/DOCX text is still extracted in-browser
  (pdf.js / mammoth), but the resulting text is POSTed to
  `/api/upload/award-letter` for the actual due-date/criteria extraction,
  with the browser's own regex pass as a fallback if the backend is
  unreachable.
- `downloadICS(id)` / `downloadAllICS()` fetch
  `GET /api/export/ics/{period}` and trigger a real file download. A new
  "📝 Word" button next to "📄 Template" fetches
  `GET /api/export/report/{period}/{deadline_id}?fmt=docx` in addition to
  the existing `fmt=txt`.
- `GET /api/export/narrative/{period}/{deadline_id}`,
  `GET /api/export/board-deck/{period}`, and
  `GET /api/export/annual-report-paragraph/{period}` are implemented on
  the backend but not yet wired to a button anywhere in the UI — worth
  adding if the board-deck / annual-report workflows are ones staff want
  from inside the dashboard itself.

`dashboard_adapter.py`'s output shape needed no changes — it already
matched the dashboard's `financeTableData` / `programTableData` /
`revenueByFunder` / `deadlines` arrays exactly.

## Expected file formats

| System | Format | Required columns |
|---|---|---|
| DonorPerfect | CSV | `gift_date`, `amount` (optional: `gl_code`/`fund`/`campaign`, `donor_id`) |
| Charity Tracker | CSV | `service_date`, `outcome_metric`, `outcome_value` (optional: `case_id`, `program`) |
| Excel/GL | .xlsx or CSV | `gl_line`, `month_actual`, `ytd_actual`, `ytd_budget` |
| EHR | CSV | `encounter_date`, `encounter_type` (optional: `client_ref`, de-identified) |

Sample files matching this layout are the fastest way to verify a new
connector before pointing it at a real monthly export.

## Adding a new funder

Add one block to `app/mapping/funder_profiles.json`:

```json
"my_new_funder": {
  "label": "My New Funder",
  "field_aliases": {"Participants Served": "Clients Served"},
  "currency_format": "USD_DOLLARS",
  "count_format": "INTEGER",
  "reporting_frequency": "quarterly"
}
```

No other code changes needed — every export endpoint accepts a
`funder_profile_id` and relabels/reformats the same underlying numbers.
